"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const PIXI = __importStar(require("pixi.js"));
//import * as factory from './scenes/factory'
const factoryScene_1 = require("./scenes/factoryScene");
const demoScene_1 = require("../src/scenes/demoScene");
require('../assets/main.css');
console.log("works");
const app = new PIXI.Application({
    width: window.innerWidth, height: window.innerHeight,
    backgroundColor: 0x1099bb, resolution: window.devicePixelRatio || 1,
});
document.body.appendChild(app.view);
const scenes = {
    factoryScene: new factoryScene_1.factoryScene(app),
    demoScene: new demoScene_1.demoScene(app)
};
scenes.demoScene.showScene();
//# sourceMappingURL=main.js.map